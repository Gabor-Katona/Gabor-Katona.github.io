// ----------------------------------------------------------------------------
// Copyright (c) 2018 Semiconductor Components Industries LLC
// (d/b/a "ON Semiconductor").  All rights reserved.
// This software and/or documentation is licensed by ON Semiconductor under
// limited terms and conditions.  The terms and conditions pertaining to the
// software and/or documentation are available at
// http://www.onsemi.com/site/pdf/ONSEMI_T&C.pdf ("ON Semiconductor Standard
// Terms and Conditions of Sale, Section 8 Software") and if applicable the
// software license agreement.  Do not use this software and/or documentation
// unless you have carefully read and you agree to the limited terms and
// conditions.  By using this software and/or documentation, you agree to the
// limited terms and conditions.
// ----------------------------------------------------------------------------

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <BDK.h>
#include <BSEC_ENV.h>
#include <ics/CS.h>
#include <ics/node/CSN_ENV.h>
#include <SoftwareTimer.h>

//-----------------------------------------------------------------------------
// DEFINES / CONSTANTS
//-----------------------------------------------------------------------------

#define CSN_ENV_NODE_NAME              "EV"

#define CSN_ENV_AVAIL_BIT              ((uint32_t)0x00000040)

#define CSN_ENV_SAMPLE_PERIOD_MS       (3000)

#define CSN_ENV_TEMP_OFFSET            (0)

#define CSN_ENV_PROP_CNT               (8)


// Shortcut macros for logging of ALS node messages.
#define CSN_ENV_Error(...) CS_LogError("ENV", __VA_ARGS__)
#define CSN_ENV_Warn(...) CS_LogWarning("ENV", __VA_ARGS__)
#define CSN_ENV_Info(...) CS_LogInfo("ENV", __VA_ARGS__)
#define CSN_ENV_Verbose(...) CS_LogVerbose("ENV", __VA_ARGS__)

/* Defines the sample rate of sensor outputs.
 *
 * The standard BSEC sample rates are:
 *
 * * BSEC_SAMPLE_RATE_LP - Low power mode with sample period of 3 seconds.
 * * BSEC_SAMPLE_RATE_ULP - Ultra low power mode with sample period of 5 minutes.
 */
#define CSN_BSEC_SAMPLE_RATE            BSEC_SAMPLE_RATE_LP

/* Static temperature offset that will be subtracted from all temperature
 * measurements. It compensates for other heat sources located near BME680.
 */
#define CSN_BSEC_TEMPERATURE_OFFSET     (0.0f)

/* Total number of desired virtual outputs.
 *
 * This value should match with the number of declared sensors in the
 * CSN_BSEC_REQUESTED_SENSORS below.
 */
#define CSN_BSEC_REQUESTED_SENSOR_COUNT (4)

/* Initialize value for BSEC requested sensor outputs.
 *
 * It consists of desired virtual sensor outputs and their sample rates.
 */
#define CSN_BSEC_REQUESTED_SENSORS { \
    { CSN_BSEC_SAMPLE_RATE, BSEC_OUTPUT_IAQ }, \
    { CSN_BSEC_SAMPLE_RATE, BSEC_OUTPUT_SENSOR_HEAT_COMPENSATED_TEMPERATURE }, \
    { CSN_BSEC_SAMPLE_RATE, BSEC_OUTPUT_SENSOR_HEAT_COMPENSATED_HUMIDITY }, \
    { CSN_BSEC_SAMPLE_RATE, BSEC_OUTPUT_RAW_PRESSURE }, \
}

/* Initializer value for BSEC init structure used to initialize the BSEC library.
 */
#define CSN_BSEC_INIT_STRUCT_VALUE { \
    .temperature_offset = CSN_BSEC_TEMPERATURE_OFFSET, \
    .sleep = CSN_BsecSleep, \
    .config_load = NULL, \
    .state_load = NULL, \
    .requested_virtual_sensors = CSN_BSEC_REQUESTED_SENSORS, \
    .n_requested_virtual_sensors = CSN_BSEC_REQUESTED_SENSOR_COUNT, \
}

/* Initializer value for BSEC process structure that defines runtime behavior.
 *
 */
#define CSN_BSEC_PROCESS_STRUCT_VALUE { \
    .sleep = CSN_BsecSleep, \
    .get_timestamp_us = CSN_BsecGetTimestampUs, \
    .output_ready = CSN_BsecOutputReady, \
    .save_state = NULL, \
    .save_interval = 1, \
}

//-----------------------------------------------------------------------------
// EXTERNAL / FORWARD DECLARATIONS
//-----------------------------------------------------------------------------

/** \brief Handler for CS requests provided in node structure. */
static int CSN_ENV_RequestHandler(const struct CS_Request_Struct* request,
                                  char* response);

// Temperature sensor Properties
static int CSN_ENV_T_PropHandler(char* response);
static int CSN_ENV_TF_PropHandler(char* response);

// Pressure sensor Properties
static int CSN_ENV_P_PropHandler(char* response);
static int CSN_ENV_PP_PropHandler(char* response);

// Humidity sensor Properties
static int CSN_ENV_H_PropHandler(char* response);

// IAQ sensor Properties
static int CSN_ENV_A_PropHandler(char* response);

// Composite requests
static int CSN_ENV_D_PropHandler(char* response);
static int CSN_ENV_DI_PropHandler(char* response);

static void CSN_BsecSleep(uint32_t t_ms);
static int64_t CSN_BsecGetTimestampUs();
static void CSN_BsecOutputReady(bsec_env_output_struct *output);

static void CSN_BsecTimerCallback(void *arg);

//-----------------------------------------------------------------------------
// INTERNAL VARIABLES
//-----------------------------------------------------------------------------

/** \brief Indicates whether MULTISENSOR-GEVB was successfully detected by
 * CSN_ENV_CheckAvailibility function.
 */
static bool env_available = false;

static bsec_env_output_struct env_data;

static struct SwTimer env_timer;

static bsec_env_process_struct env_process_params = CSN_BSEC_PROCESS_STRUCT_VALUE;

/** \brief CS node structure passed to CS. */
static struct CS_Node_Struct env_node = {
        CSN_ENV_NODE_NAME,
        CSN_ENV_AVAIL_BIT,
        &CSN_ENV_RequestHandler
};

struct CSN_ENV_Property_Struct
{
    const char* name;
    const char* prop_def;
    int (*callback)(char* response);
};

static struct CSN_ENV_Property_Struct env_prop[CSN_ENV_PROP_CNT] = {
        { "T",  "p/R/f/T",  &CSN_ENV_T_PropHandler},
        { "TF", "p/R/f/TF", &CSN_ENV_TF_PropHandler},
        { "P",  "p/R/f/P",  &CSN_ENV_P_PropHandler},
        { "PP", "p/R/f/PP", &CSN_ENV_PP_PropHandler},
        { "H",  "p/R/f/H",  &CSN_ENV_H_PropHandler},
        { "A",  "p/R/i/A",  &CSN_ENV_A_PropHandler},
        { "D",  "p/R/c/D",  &CSN_ENV_D_PropHandler},
        { "DI", "p/R/c/DI", &CSN_ENV_DI_PropHandler}
};


//-----------------------------------------------------------------------------
// FUNCTION DEFINITIONS
//-----------------------------------------------------------------------------

/** \brief Checks if MULTISENSOR-GEVB (NOA1306) is connected to baseboard.
 *
 *  This check needs to be executed before any other CSN_ALS2 functions are
 *  called or they will fail.
 *
 *  \returns 0 If MULTISENSOR-GEVB is not present.
 *  \returns 1 If MULTISENSOR-GEVB is connected to Baseboard and is responding.
 */
bool CSN_ENV_CheckAvailability()
{
    bsec_env_return_val retval;
    bsec_env_init_struct init_params = CSN_BSEC_INIT_STRUCT_VALUE;

    retval = BSEC_ENV_Initialize(&init_params);
    if (retval.bme680_status == BME680_OK && retval.bsec_status == BSEC_OK)
    {
        env_available = true;
    }
    else
    {
        env_available = false;
        CSN_ENV_Warn("MULTI-SENSE-GEVB shield not connected.");
    }

    return env_available;
}

/** \brief Returns cached result of CSN_ENV_CheckAvailibility.
 *
 *  \returns 0 If ALS-GEVB is not present.
 *  \returns 1 If ALS-GEVB is connected to Baseboard and is responding.
 */
bool CSN_ENV_IsAvailable()
{
    return env_available;
}

struct CS_Node_Struct* CSN_ENV_Create()
{
    if (env_available)
    {
        SwTimer_Initialize(&env_timer);
        SwTimer_AttachScheduled(&env_timer, CSN_BsecTimerCallback, NULL);
        SwTimer_ExpireInMs(&env_timer, 1);

        return &env_node;
    }

    return NULL;
}

void CSN_BsecSleep(uint32_t t_ms)
{
    HAL_Delay(t_ms);
}

void CSN_BsecOutputReady(bsec_env_output_struct *output)
{
    memcpy(&env_data, output, sizeof(bsec_env_output_struct));
}

/* Retrieves current system time stamp.
 *
 * The system uses 32-bit counter incremented every ms.
 * Therefore some additional logic was added to handle counter overflow and
 * expands the time stamp into 64-bit value.
 */
int64_t CSN_BsecGetTimestampUs()
{
    static int64_t timestamp = 0;
    static struct tm_math math;
    static uint32_t last = 0;

    uint32_t now, diff;

    if (timestamp == 0)
    {
        tm_initialize(&math, UINT32_MAX);
        last = 0;
    }

    now = HAL_Time();
    diff = tm_get_diff(&math, now, last);
    last = now;

    timestamp += diff;

    return timestamp * 1000;
}

static void CSN_BsecTimerCallback(void *arg)
{
    int32_t next_call = 0;

    next_call = BSEC_ENV_Process(&env_process_params);

    SwTimer_ExpireInMs(&env_timer, next_call);
}

static int CSN_ENV_RequestHandler(const struct CS_Request_Struct* request, char* response)
{
    // Check request type
    if (request->property_value != NULL)
    {
        CSN_ENV_Error("ALS properties support only read requests.");
        strcpy(response, "e/ACCESS");
        return CS_OK;
    }

    // AO Data property requests
    for (int i = 0; i < CSN_ENV_PROP_CNT; ++i)
    {
        if (strcmp(request->property, env_prop[i].name) == 0)
        {
            if (env_prop[i].callback(response) != CS_OK)
            {
                strcpy(response, "e/NODE_ERR");
            }
            return CS_OK;
        }
    }

    // PROP property request
    if (strcmp(request->property, "PROP") == 0)
    {
        sprintf(response, "i/%d", CSN_ENV_PROP_CNT);
        return CS_OK;
    }

    // NODEx property request
    if (strlen(request->property) > 4 &&
        memcmp(request->property, "PROP", 4) == 0)
    {
        // check if there are only digits after first 4 characters
        char* c = (char*)&request->property[4];
        int valid_number = 1;
        while (*c != '\0')
        {
            if (isdigit(*c) == 0)
            {
                valid_number = 0;
                break;
            }
            ++c;
        }

        if (valid_number == 1)
        {
            int prop_index = atoi(&request->property[4]);
            if (prop_index >= 0 && prop_index < CSN_ENV_PROP_CNT)
            {
                sprintf(response, "n/%s", env_prop[prop_index].prop_def);
                return CS_OK;
            }
            else
            {
                CSN_ENV_Error("Out of bound NODEx request.");
                // Invalid property error
            }
        }
        else
        {
            // Invalid property error
        }
    }

    CSN_ENV_Error("ENV property '%s' does not exist.", request->property);
    strcpy(response, "e/UNK_PROP");
    return CS_OK;
}


static int CSN_ENV_T_PropHandler(char* response)
{
    float t = env_data.temperature;
    sprintf(response, "f/%.2f", t);
    return CS_OK;
}

static int CSN_ENV_TF_PropHandler(char* response)
{
    sprintf(response, "f/%.2f", (env_data.temperature) * 1.8f + 32);
    return CS_OK;
}

static int CSN_ENV_P_PropHandler(char* response)
{
    sprintf(response, "f/%.2f", env_data.raw_pressure / 1000.0f);
    return CS_OK;
}

static int CSN_ENV_PP_PropHandler(char* response)
{
    sprintf(response, "f/%.2f", env_data.raw_pressure * 0.000145f);
    return CS_OK;
}

static int CSN_ENV_H_PropHandler(char* response)
{
    sprintf(response, "f/%.2f", env_data.humidity);
    return CS_OK;
}

static int CSN_ENV_A_PropHandler(char* response)
{
    sprintf(response, "i/%.0f", env_data.iaq);
    return CS_OK;
}

static int CSN_ENV_D_PropHandler(char* response)
{
    snprintf(response, 19, "%.0f,%.0f,%.0f,%.2f",
            (env_data.temperature * 10.0f), env_data.humidity,
            env_data.iaq, env_data.raw_pressure / 100.0f);
    return CS_OK;
}

static int CSN_ENV_DI_PropHandler(char* response)
{
    int temp = (((env_data.temperature) * 1.8f + 32.0f) * 10.0f);
    int pressure = env_data.raw_pressure * 0.000145f * 10.0f;

    snprintf(response, 19, "%d,%d,%d,%d", temp,
            (int) (env_data.humidity / 1000), 0, pressure);
    return CS_OK;
}
