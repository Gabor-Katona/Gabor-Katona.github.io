//-----------------------------------------------------------------------------
// Copyright (c) 2018 Semiconductor Components Industries LLC
// (d/b/a "ON Semiconductor").  All rights reserved.
// This software and/or documentation is licensed by ON Semiconductor under
// limited terms and conditions.  The terms and conditions pertaining to the
// software and/or documentation are available at
// http://www.onsemi.com/site/pdf/ONSEMI_T&C.pdf ("ON Semiconductor Standard
// Terms and Conditions of Sale, Section 8 Software") and if applicable the
// software license agreement.  Do not use this software and/or documentation
// unless you have carefully read and you agree to the limited terms and
// conditions.  By using this software and/or documentation, you agree to the
// limited terms and conditions.
//-----------------------------------------------------------------------------
//! \file RTE_BDK_AMIS30543_STPR.h
//!
//! \addtogroup BDK_GRP
//! \{
//! \addtogroup COMPONENTS
//! \{
//! \addtogroup AMIS_STPR_GRP
//! \{
//! \name Run Time Environment Configuration
//! \{
//!
//! These parameters are part of the \ref RTE_AMIS30543_STPR.h RTE configuration
//! file and can be used to adjust library behavior.
//! This file is copied into the Eclipse project when the AMIS30453_STPR
//! component is selected and can be edited by using the <i>CMIS Configuration
//! Wizard</i> editor.
//!
//! These parameters allow to modify all SPI configurable parameters of the
//! AMIS-30543 Stepper motor driver.
//!
//! \image html rte_amis_stpr.jpg
//!
//-----------------------------------------------------------------------------
#ifndef RTE_AMIS30543_STPR_H_
#define RTE_AMIS30543_STPR_H_

// <<< Use Configuration Wizard in Context Menu >>>

// <h> Stepper Shield Left Channel

// <o> Step Mode
// <i> Default: 1 / 4 Micro - Step (for motors provided with Stepper shield)
//   <0x01=> 1 / 128 Micro - Step
//   <0x02=> 1 / 64 Micro - Step
//   <0x00=> 1 / 32 Micro - Step
//   <0x10=> 1 / 16 Micro - Step
//   <0x20=> 1 / 8 Micro - Step
//   <0x30=> 1 / 4 Micro - Step
//   <0x40=> Compensated Half Step
//   <0x50=> Uncompensated Half Step
//   <0x60=> Uncompensated Full Step
//   <0x03=> Compensated Full Step, 2 phase on
//   <0x04=> Compensated Full Step, 1 phase on
#define RTE_AMIS_STPR_LEFT_STEP_MODE   0x30

// <o> Coil Peak Current
// <i> Default: 245 mA (for motors provided with Stepper shield)
//   <0=> 132 mA
//   <1=> 245 mA
//   <2=> 355 mA
//   <3=> 395 mA
//   <4=> 445 mA
//   <5=> 485 mA
//   <6=> 540 mA
//   <7=> 585 mA
//   <8=> 640 mA
//   <9=> 715 mA
//   <10=> 780 mA
//   <11=> 870 mA
//   <12=> 955 mA
//   <13=> 1060 mA
//   <14=> 1150 mA
//   <15=> 1260 mA
//   <16=> 1405 mA
//   <17=> 1520 mA
//   <18=> 1695 mA
//   <19=> 1850 mA
//   <20=> 2070 mA
//   <21=> 2240 mA
//   <22=> 2440 mA
//   <23=> 2700 mA
//   <24=> 2845 mA
//   <25=> 3000 mA
#define RTE_AMIS_STPR_LEFT_CURRENT     1

// <o> Direction Of Rotation
// <i> This library uses the DIR pin to change rotation direction.
// <i> This setting can be used to invert rotation direction.
// <i> Direction depends on combination of this setting, DIR pin level and motor wiring.
// <i> Default: CW motion
//   <0=> CW motion
//   <1=> CCW motion
#define RTE_AMIS_STPR_LEFT_DIRCTRL     0

// <o> NXT Edge Trigger
// <i> Selects if NXT triggers on rising or falling edge.
// <i> Default: Rising Edge
//   <0=> Rising Edge
//   <1=> Falling Edge
#define RTE_AMIS_STPR_LEFT_NXTP        0

// <o> Turn On / Off Slopes of Motor Driver
// <i> Default: Very Fast
//   <0=> Very Fast
//   <1=> Fast
//   <2=> Slow
//   <3=> Very Slow
#define RTE_AMIS_STPR_LEFT_EMC         0

// <o> Speed Load Angle Transparency Bit
// <i> Default: SLA is not transparent
//   <0=> SLA is not transparent
//   <1=> SLA is transparent
#define RTE_AMIS_STPR_LEFT_SLAT        0

// <o> Speed Load Angle Gain
// <i> Default: 0.5
//   <0=> 0.5
//   <1=> 0.25
#define RTE_AMIS_STPR_LEFT_SLAG        0

// <q> Enables doubling of the PWM frequency
// <i> Default: Disabled
#define RTE_AMIS_STPR_LEFT_PWMF        0

// <q> Enables jittery PWM
// <i> Default: Disabled
#define RTE_AMIS_STPR_LEFT_PWMJ        0

// <o> Steps Per Revolution <0-1000000>
// <i> Stepper Motor parameter that determines how many steps it takes to do full 360� revolution.
// <i> Default: 200 (For motors provided with Stepper Shield)
#define RTE_AMIS_STPR_LEFT_SPR         200

// </h>

// <h> Stepper Shield Right Channel

// <o> Step Mode
// <i> Default: 1 / 4 Micro - Step (for motors provided with Stepper shield)
//   <0x01=> 1 / 128 Micro - Step
//   <0x02=> 1 / 64 Micro - Step
//   <0x00=> 1 / 32 Micro - Step
//   <0x10=> 1 / 16 Micro - Step
//   <0x20=> 1 / 8 Micro - Step
//   <0x30=> 1 / 4 Micro - Step
//   <0x40=> Compensated Half Step
//   <0x50=> Uncompensated Half Step
//   <0x60=> Uncompensated Full Step
//   <0x03=> Compensated Full Step, 2 phase on
//   <0x04=> Compensated Full Step, 1 phase on
#define RTE_AMIS_STPR_RIGHT_STEP_MODE   0x30

// <o> Coil Peak Current
// <i> Default: 245 mA (for motors provided with Stepper shield)
//   <0=> 132 mA
//   <1=> 245 mA
//   <2=> 355 mA
//   <3=> 395 mA
//   <4=> 445 mA
//   <5=> 485 mA
//   <6=> 540 mA
//   <7=> 585 mA
//   <8=> 640 mA
//   <9=> 715 mA
//   <10=> 780 mA
//   <11=> 870 mA
//   <12=> 955 mA
//   <13=> 1060 mA
//   <14=> 1150 mA
//   <15=> 1260 mA
//   <16=> 1405 mA
//   <17=> 1520 mA
//   <18=> 1695 mA
//   <19=> 1850 mA
//   <20=> 2070 mA
//   <21=> 2240 mA
//   <22=> 2440 mA
//   <23=> 2700 mA
//   <24=> 2845 mA
//   <25=> 3000 mA
#define RTE_AMIS_STPR_RIGHT_CURRENT     1

// <o> Direction Of Rotation
// <i> This library uses the DIR pin to change rotation direction.
// <i> This setting can be used to invert rotation direction.
// <i> Direction depends on combination of this setting, DIR pin level and motor wiring.
// <i> Default: CW motion
//   <0=> CW motion
//   <1=> CCW motion
#define RTE_AMIS_STPR_RIGHT_DIRCTRL     0

// <o> NXT Edge Trigger
// <i> Selects if NXT triggers on rising or falling edge.
// <i> Default: Rising Edge
//   <0=> Rising Edge
//   <1=> Falling Edge
#define RTE_AMIS_STPR_RIGHT_NXTP        0

// <o> Turn On / Off Slopes of Motor Driver
// <i> Default: Very Fast
//   <0=> Very Fast
//   <1=> Fast
//   <2=> Slow
//   <3=> Very Slow
#define RTE_AMIS_STPR_RIGHT_EMC         0

// <o> Speed Load Angle Transparency Bit
// <i> Default: SLA is not transparent
//   <0=> SLA is not transparent
//   <1=> SLA is transparent
#define RTE_AMIS_STPR_RIGHT_SLAT        0

// <o> Speed Load Angle Gain
// <i> Default: 0.5
//   <0=> 0.5
//   <1=> 0.25
#define RTE_AMIS_STPR_RIGHT_SLAG        0

// <q> Enables doubling of the PWM frequency
// <i> Default: Disabled
#define RTE_AMIS_STPR_RIGHT_PWMF        0

// <q> Enables jittery PWM
// <i> Default: Disabled
#define RTE_AMIS_STPR_RIGHT_PWMJ        0

// <o> Steps Per Revolution <0-1000000>
// <i> Stepper Motor parameter that determines how many steps it takes to do full 360� revolution.
// <i> Default: 200 (For motors provided with Stepper Shield)
#define RTE_AMIS_STPR_RIGHT_SPR         200

// </h>

// <<< end of configuration section >>>

#endif /* RTE_AMIS30543_STPR_H_ */

//! \}
//! \}
//! \}
//! \}
