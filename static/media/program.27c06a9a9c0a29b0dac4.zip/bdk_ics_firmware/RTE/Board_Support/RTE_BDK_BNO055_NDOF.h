//-----------------------------------------------------------------------------
// Copyright (c) 2018 Semiconductor Components Industries LLC
// (d/b/a "ON Semiconductor").  All rights reserved.
// This software and/or documentation is licensed by ON Semiconductor under
// limited terms and conditions.  The terms and conditions pertaining to the
// software and/or documentation are available at
// http://www.onsemi.com/site/pdf/ONSEMI_T&C.pdf ("ON Semiconductor Standard
// Terms and Conditions of Sale, Section 8 Software") and if applicable the
// software license agreement.  Do not use this software and/or documentation
// unless you have carefully read and you agree to the limited terms and
// conditions.  By using this software and/or documentation, you agree to the
// limited terms and conditions.
//-----------------------------------------------------------------------------
//! \file RTE_BDK_BNO055_NDOF.h
//!
//! \addtogroup BDK_GRP
//! \{
//! \addtogroup COMPONENTS
//! \{
//! \addtogroup BNO055_NDOF_GRP
//! \{
//! \name Run Time Environment Configuration
//! \{
//!
//! These parameters are part of the \ref RTE_BNO055_NDOF.h RTE configuration
//! file and can be used to adjust library behavior.
//! This file is copied into the Eclipse project when the BNO055_NDOF component
//! is selected and can be edited by using the <i>CMIS Configuration Wizard</i>
//! editor.
//-----------------------------------------------------------------------------
#ifndef RTE_BNO055_NDOF_H_
#define RTE_BNO055_NDOF_H_

#include <stdbool.h>
#include <stdint.h>

// <<< Use Configuration Wizard in Context Menu >>>

// <o> Use external 32.768 kHz crystal
//  <0=> Disabled
//  <1=> Enabled
#ifndef RTE_BNO055_NDOF_EXT_CLK_SRC
#define RTE_BNO055_NDOF_EXT_CLK_SRC      1
#endif

// <<< end of configuration section >>>

#endif /* RTE_BNO055_NDOF_H_ */

//! \}
//! \}
//! \}
//! \}
