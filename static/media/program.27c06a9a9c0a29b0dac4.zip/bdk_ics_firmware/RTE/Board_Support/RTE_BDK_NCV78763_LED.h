//-----------------------------------------------------------------------------
// Copyright (c) 2018 Semiconductor Components Industries LLC
// (d/b/a "ON Semiconductor").  All rights reserved.
// This software and/or documentation is licensed by ON Semiconductor under
// limited terms and conditions.  The terms and conditions pertaining to the
// software and/or documentation are available at
// http://www.onsemi.com/site/pdf/ONSEMI_T&C.pdf ("ON Semiconductor Standard
// Terms and Conditions of Sale, Section 8 Software") and if applicable the
// software license agreement.  Do not use this software and/or documentation
// unless you have carefully read and you agree to the limited terms and
// conditions.  By using this software and/or documentation, you agree to the
// limited terms and conditions.
//-----------------------------------------------------------------------------
//! \file RTE_BDK_NCV78763_LED.h
//!
//! This file contains the Run Time Configuration (RTE) options for NCV78763_LED
//! CMSIS Component.
//!
//! These options can be edited by opening this file in CMSIS Configuration
//! Wizard Editor that is part of Eclipse installation.
//!
//! \addtogroup BDK_GRP
//! \{
//! \addtogroup COMPONENTS
//! \{
//! \addtogroup NCV78763_LED_GRP
//! \{
//! \name Run Time Environment Configuration
//! \{
//! These parameters are part of the \ref RTE_NCV78763_LED.h RTE configuration
//! file and can be used to adjust library behavior.
//! This file is copied into the Eclipse project when the NCV78763_LED component
//! is selected and can be edited by using the <i>CMIS Configuration Wizard</i>
//! editor.
//!
//! \image html rte_ncv78763_led.jpg
//-----------------------------------------------------------------------------
#ifndef RTE_NCV78763_LED_H_
#define RTE_NCV78763_LED_H_

#include <stdbool.h>
#include <stdint.h>

// <<< Use Configuration Wizard in Context Menu >>>

// <e> Enable Booster
// <i> Controls the activation status of the booster.
// <i> Default: Enabled for D-LED-B-GEVK
#define RTE_NCV78763_LED_BOOST_EN  1

// <o> Booster PWM generation
// <i>Default: Internal for D-LED-B-GEVK
//   <0=> Internal
//   <1=> External
#define RTE_NCV78763_LED_BOOST_SRC  0

// <o> Booster PWM Frequency
// <i> Selects Booster PWM frequency in Internal generation mode.
// <i> Default: 242 kHz for D-LED-B-GEVK
//   <0=> Clock Disabled
//   <1=> 1000 kHz
//   <2=> 888 kHz
//   <3=> 800 kHz
//   <4=> 727 kHz
//   <5=> 666 kHz
//   <6=> 615 kHz
//   <7=> 571 kHz
//   <8=> 533 kHz
//   <9=> 500 kHz
//   <10=> 470 kHz
//   <11=> 444 kHz
//   <12=> 421 kHz
//   <13=> 400 kHz
//   <14=> 380 kHz
//   <15=> 363 kHz
//   <16=> 347 kHz
//   <17=> 333 kHz
//   <18=> 320 kHz
//   <19=> 307 kHz
//   <20=> 296 kHz
//   <21=> 285 kHz
//   <22=> 275 kHz
//   <23=> 266 kHz
//   <24=> 258 kHz
//   <25=> 250 kHz
//   <26=> 242 kHz
//   <27=> 235 kHz
//   <28=> 228 kHz
//   <29=> 222 kHz
//   <30=> 216 kHz
//   <31=> 210 kHz
#define RTE_NCV78763_LED_BOOST_FREQ  26

// <q> Booster Clock Inversion
// <i> Controls the polarity of the clock source.
// <i> "1" = inverted
// <i> Default: 0 for D-LED-B-GEVK
#define RTE_NCV78763_LED_BOOST_SRC_INV  0

// <o> Booster Slope Compensation
// <i> Default: 10 mV / us for D-LED-B-GEVK
//   <0=> No Slope Control
//   <1=> 5 mV / us
//   <2=> 10 mV / us
//   <3=> 20 mV / us
#define RTE_NCV78763_LED_BOOST_SLPCTRL  2

// <o> Booster Error Amplifier Gain [Siemens]
// <i> Default: 30 uS for D-LED-B-GEVK
//   <0=> High Impedance
//   <1=> 30 uS
//   <2=> 60 uS
//   <3=> 90 uS
#define RTE_NCV78763_LED_BOOST_OTA_GAIN  1

// <o> Booster Overvoltage Shutdown
// <i> Controls the maximum allowed overshoot with respect to the regulation target.
// <i> Default: 5.8 V for D-LED-B-GEVK
//   <0=> 1 V
//   <1=> 1.5 V
//   <2=> 2 V
//   <3=> 2.4 V
//   <4=> 2.9 V
//   <5=> 3.9 V
//   <6=> 4.85 V
//   <7=> 5.8 V
#define RTE_NCV78763_LED_BOOST_OV_SD  7

// <o> Booster Overvoltage Reactivation
// <i> Defines the hysteresis for the reactivation once the overvoltage shutdown is triggered.
// <i> Default: -1 V for D-LED-B-GEVK
//   <0=> 0 V
//   <1=> -0.5 V
//   <2=> -1 V
//   <3=> -1.4 V
#define RTE_NCV78763_LED_BOOST_OV_REACT  2

// <o> Booster Gate Voltage Threshold
// <i> Default: 0 For D-LED-B-GEVK
//   <0=> 0.4 V
//   <1=> 1.2 V
#define RTE_NCV78763_LED_BOOST_VGATE_THR  0

// <o> Booster Minimum Off Time
// <i> Default: 115 ns for D-LED-B-GEVK
//   <0=> 115 ns
//   <1=> 75 ns
//   <2=> 195 ns
//   <3=> 155 ns
#define RTE_NCV78763_LED_BOOST_MIN_TOFF  0

// <o> Booster Minimum On Time
// <i> Default: 150 ns for D-LED-B-GEVK
//   <0=> 150 ns
//   <1=> 200 ns
//   <2=> 260 ns
//   <3=> 300 ns
#define RTE_NCV78763_LED_BOOST_TON_SET  0

// <o> Booster Regulation Setpoint Voltage
// <i> Default: 45 V for D-LED-B-GEVK
//   <0=> 11.0 V
//   <1=> 15.0 V     <2=> 15.4 V   <3=> 15.8 V   <4=> 16.2 V   <5=> 16.6 V
//   <6=> 16.9 V     <7=> 17.3 V   <8=> 17.7 V   <9=> 18.1 V  <10=> 18.5 V
//   <11=> 18.9 V   <12=> 19.3 V  <13=> 19.7 V  <14=> 20.1 V  <15=> 20.5 V
//   <16=> 20.9 V   <17=> 21.2 V  <18=> 21.6 V  <19=> 22.0 V  <20=> 22.4 V
//   <21=> 22.8 V   <22=> 23.2 V  <23=> 23.6 V  <24=> 24.0 V  <25=> 24.4 V
//   <26=> 24.8 V   <27=> 25.1 V  <28=> 25.5 V  <29=> 25.9 V  <30=> 26.3 V
//   <31=> 26.7 V   <32=> 27.1 V  <33=> 27.5 V  <34=> 27.9 V  <35=> 28.3 V
//   <36=> 28.6 V   <37=> 29.0 V  <38=> 29.4 V  <39=> 29.8 V  <40=> 30.2 V
//   <41=> 30.6 V   <42=> 31.0 V  <43=> 31.4 V  <44=> 31.8 V  <45=> 32.2 V
//   <46=> 32.5 V   <47=> 32.9 V  <48=> 33.3 V  <49=> 33.7 V  <50=> 34.1 V
//   <51=> 34.5 V   <52=> 34.9 V  <53=> 35.3 V  <54=> 35.7 V  <55=> 36.1 V
//   <56=> 36.5 V   <57=> 36.8 V  <58=> 37.2 V  <59=> 37.6 V  <60=> 38.0 V
//   <61=> 38.4 V   <62=> 38.8 V  <63=> 39.2 V  <64=> 39.6 V  <65=> 40.0 V
//   <66=> 40.4 V   <67=> 40.7 V  <68=> 41.1 V  <69=> 41.5 V  <70=> 41.9 V
//   <71=> 42.3 V   <72=> 42.7 V  <73=> 43.1 V  <74=> 43.5 V  <75=> 43.9 V
//   <76=> 44.2 V   <77=> 44.6 V  <78=> 45.0 V  <79=> 45.4 V  <80=> 45.8 V
//   <81=> 46.2 V   <82=> 46.6 V  <83=> 47.0 V  <84=> 47.4 V  <85=> 47.8 V
//   <86=> 48.1 V   <87=> 48.5 V  <88=> 48.9 V  <89=> 49.3 V  <90=> 49.7 V
//   <91=> 50.1 V   <92=> 50.5 V  <93=> 50.9 V  <94=> 51.3 V  <95=> 51.7 V
//   <96=> 52.1 V   <97=> 52.4 V  <98=> 52.8 V  <99=> 53.2 V <100=> 53.6 V
//   <101=> 54.0 V <102=> 54.4 V <103=> 54.8 V <104=> 55.2 V <105=> 55.6 V
//   <106=> 56.0 V <107=> 56.3 V <108=> 56.7 V <109=> 57.1 V <110=> 57.5 V
//   <111=> 57.9 V <112=> 58.3 V <113=> 58.7 V <114=> 59.1 V <115=> 59.5 V
//   <116=> 59.9 V <117=> 60.2 V <118=> 60.6 V <119=> 61.0 V <120=> 61.4 V
//   <121=> 61.8 V <122=> 62.2 V <123=> 62.6 V <124=> 63.0 V <125=> 63.4 V
//   <126=> 63.8 V <127=> 64.1 V
#define RTE_NCV78763_LED_BOOST_VSETPOINT  78

// <o> Booster Current Limitation Peak Value
// Default: 100 mV for D-LED-B-GEVK
//   <0=> 50 mV
//   <1=> 62.5 mV
//   <2=> 80 mV
//   <3=> 100 mV
#define RTE_NCV78763_LED_BOOST_VLIMTH  3

// <q> Activate VBOOST_AUX_SUPPLY
// <i> Controls the activation of the VBOOST_AUX_SUPPLY (VDRIVE powered via the booster for low battery voltages).
// <i> Default: 0 for D-LED-B-GEVK
#define RTE_NCV78763_LED_VDRIVE_BST_EN  0

// <o> Booster Skip Clock Cycles
// <i> Booster skip cycle for low currents
// <i> Default: Disabled for D-LED-B-GEVK
//   <0=> Disabled
//   <1=> 0.6 V
//   <2=> 0.7 V
//   <3=> 0.8 V
#define RTE_NCV78763_LED_BOOST_SKCL  0

// </e>

// <e> Enable Buck Regulator Channel 1
// <i> Default: Enabled for D-LED-GEVK
#define RTE_NCV78763_LED_BUCK1_EN  1

// <o> D-LED-B-GEVK Channel 1 Peak current [mA] <158-2060>
// <i> Warning: Not all combinations of Peak & Average current settings are possible.
// <i> If selected settings are not possible the NCV78763_LED_Initialize will return OUT_OF_RANGE error.
// <i> Default: 252 mA
#define RTE_NCV78763_LED_BUCK1_PEAK_CUR  252

// <o> D-LED-B-GEVK Channel 1 Average current [mA] <0-1275>
// <i> Warning: Not all combinations of Peak & Average current settings are possible.
// <i> If selected settings are not possible the NCV78763_LED_Initialize will return OUT_OF_RANGE error.
// <i> Default: 140 mA
#define RTE_NCV78763_LED_BUCK1_AVG_CUR  140

// <q> Enables the offset compensation for buck 1.
// <i> Default: 0 for D-LED-B-GEVK
#define RTE_NCV78763_LED_BUCK1_OFF_CMP_EN  0

// <o> Comparator Threshold Voltage <0-255>
// <i> Default: 0 - Calculated by library to set desired Peak / Avg current
// <i >Non zero value will override the result of calculation with D-LED-B-GEVK component values.
#define RTE_NCV78763_LED_BUCK1_VTHR  0

// <o> Tunes the Toff x VLED value for channel 1
// <i> Default: 0 - Calculated by library to set desired Peak / Avg current
// <i >Non zero value will override the result of calculation with D-LED-B-GEVK component values.
#define RTE_NCV78763_LED_BUCK1_TOFF_VLED  0

// <h> Overcurrent Settings

// <o> Overcurrent via the ISENSE 1 comparator - counter settings <0-127>
// <i> Default: 0 for D-LED-B-GEVK
#define RTE_NCV78763_LED_BUCK1_OC_ISENSCMP_COUNT  0

// <o> Overcurrent via internal switch 1 comparator - counter settings. <0-7>
// <i> Default: 0 for D-LED-B-GEVK
#define RTE_NCV78763_LED_BUCK1_OC_OCCMP_COUNT  0

// </h>

// </e>

// <e> Enable Buck Regulator Channel 2
// <i> Default: Enabled for D-LED-GEVK
#define RTE_NCV78763_LED_BUCK2_EN  1

// <o> D-LED-B-GEVK Channel 2 Peak current [mA] <0-1275>
#define RTE_NCV78763_LED_BUCK2_PEAK_CUR  252

// <o> D-LED-B-GEVK Channel 2 Average current [mA] <0-1275>
#define RTE_NCV78763_LED_BUCK2_AVG_CUR  140

// <q> Enables the offset compensation for buck 2.
// <i> Default: 0 for D-LED-B-GEVK
#define RTE_NCV78763_LED_BUCK2_OFF_CMP_EN  0

// <o> Comparator Threshold Voltage <0-255>
// <i> Default: 0 - Calculated by library to set desired Peak / Avg current
// <i >Non zero value will override the result of calculation with D-LED-B-GEVK component values.
#define RTE_NCV78763_LED_BUCK2_VTHR  0

// <o> Tunes the Toff x VLED value for channel 2
// <i> Default: 0 - Calculated by library to set desired Peak / Avg current
// <i >Non zero value will override the result of calculation with D-LED-B-GEVK component values.
#define RTE_NCV78763_LED_BUCK2_TOFF_VLED  0

// <h> Overcurrent Settings

// <o> Overcurrent via the ISENSE 2 comparator - counter settings <0-127>
// <i> Default: 0 for D-LED-B-GEVK
#define RTE_NCV78763_LED_BUCK2_OC_ISENSCMP_COUNT  0

// <o> Overcurrent via internal switch 2 comparator - counter settings. <0-7>
// <i> Default: 0 for D-LED-B-GEVK
#define RTE_NCV78763_LED_BUCK2_OC_OCCMP_COUNT  0

// </h>

// </e>

// <h> General Settings

// <o> Thermal warning threshold <0-255>
// <i> Default: 0
#define RTE_NCV78763_LED_THERMAL_WARNING_THR  0

// <o> LED sampling duration selection <0-511>
// <i> Default: 88
#define RTE_NCV78763_LED_LED_SEL_DUR  88

// <o> Dimming generation selection
// <i> Default: internal for D-LED-B-GEVK
//   <0=> Internal
//   <1=> External
#define RTE_NCV78763_LED_DIM_SRC  0

// <o> Internal LED Dimming Frequency
// <i> Default: 1000 Hz
//   <0=> 500 Hz
//   <1=> 1000 Hz
//   <2=> 2000 Hz
//   <3=> 4000 Hz
#define RTE_NCV78763_LED_PWM_FREQ  1

// </h>

// <q> Debugging output
// <i> Prints debugging messages using printf.
// <i> Default: Disabled
#define RTE_NCV78763_DEBUG  1

// <<< end of configuration section >>>



#endif /* RTE_NCV78763_LED_H_ */

//! \}
//! \}
//! \}
//! \}
