//-----------------------------------------------------------------------------
// Copyright (c) 2018 Semiconductor Components Industries LLC
// (d/b/a "ON Semiconductor").  All rights reserved.
// This software and/or documentation is licensed by ON Semiconductor under
// limited terms and conditions.  The terms and conditions pertaining to the
// software and/or documentation are available at
// http://www.onsemi.com/site/pdf/ONSEMI_T&C.pdf ("ON Semiconductor Standard
// Terms and Conditions of Sale, Section 8 Software") and if applicable the
// software license agreement.  Do not use this software and/or documentation
// unless you have carefully read and you agree to the limited terms and
// conditions.  By using this software and/or documentation, you agree to the
// limited terms and conditions.
//-----------------------------------------------------------------------------
//! \file RTE_BDK_LV8907UW_BLDC.h
//!
//! \addtogroup BDK_GRP
//! \{
//! \addtogroup COMPONENTS
//! \{
//! \addtogroup LV8907UW_GRP
//! \{
//! \name Run Time Environment Configuration
//! \{
//!
//! These parameters are part of the \ref RTE_BDK_LV8907UW_BLDC.h RTE
//! configuration file and can be used to adjust library behavior.
//! This file is copied into the Eclipse project when the LV8907UW_BLDC
//! component is selected and can be edited by using the <i>CMIS Configuration
//! Wizard</i> editor.
//!
//! These parameters allow to modify all SPI configurable parameters of the
//! LV8907UW Brushless DC motor driver.
//!
//! \image html rte_lv8907uw_bldc.jpg
//!
//-----------------------------------------------------------------------------
#ifndef RTE_BDK_LV8907UW_BLDC_H_
#define RTE_BDK_LV8907UW_BLDC_H_

#include <stdbool.h>
#include <stdint.h>

// <<< Use Configuration Wizard in Context Menu >>>

// <h> LV8907UW Configuration

// MRCONF0

// <o> External Input System Selection
// <i> Selects source of PWM input channel.
// <i> Default: PWMIN for BLDC-GEVK
//   <0=> LIN_PWMIN
//   <1=> PWMIN
#define RTE_LV8907UW_BLDC_LINIO  1

// <q> LIN Slope Mode Setup
// <i> To improve EMI performance the LIN switching slope can be reduced.
// <i> Default: Disabled for BLDC-GEVK
#define RTE_LV8907UW_BLDC_LINSLP  0

// <e> VCC Regulator Enable
// <i> Default: Disabled for BLDC-GEVK. VCC is not used.
#define RTE_LV8907UW_BLDC_VCEN  0

// <o> VCC Voltage Selection
// <i> Default: 3.3V for BLDC-GEVK
//   <0=> 3.3 V
//   <1=> 5 V
#define RTE_LV8907UW_BLDC_REGSEL  0

// </e>

// <o> Speed Control
// <i> Determines combination of SCEN and PWMF bits.
// <i> Default: Closed Loop for BLDC-GEVK
//  <0=> Closed Loop
//  <2=> Indirect Translated
//  <3=> Direct pass-through
#define RTE_LV8907UW_BLDC_SPEED_CONTROL  0

// <q> Free-run Detection Enable
// <i> Decides if the LV8907 does a BEMF detection before attempting to start the motor open-loop excitation and commutation.
// <i> Default: Disabled for BLDC-GEVK
#define RTE_LV8907UW_BLDC_FRREN  0

// MRCONF1

// <o> PWM input signal level
// <i> Decides whether the PWM input signal is active low, or active high.
// <i> Default: Active high for BLDC-GEVK
//   <0=> High
//   <1=> Low
#define RTE_LV8907UW_BLDC_PWMON  0

// <e> Fast Startup Operation Mode
// <i> During the first 200 ms after EN high, while the PWM signal is still
// <i> being measured, the motor can be set to be driven by predefined duty cycle.
// <i> Default: Off for BLDC-GEVK
#define RTE_LV8907UW_BLDC_PDTC  0

// <o> Fast Startup PWM Input Duty Cycle
//   <0=> 25%
//   <1=> 50%
//   <2=> 75%
//   <3=> 100%
#define RTE_LV8907UW_BLDC_PDTSEL  0

// </e>

// <e> 0% PWM Operation Mode
// <i> If 0% PWM input duty cycle was detected the motor can be turned off or
// <i> driven by predefined duty cycle.
// <i> Default: Off for BLDC-GEVK
#define RTE_LV8907UW_BLDC_PWMZP  0

// <o> 0% PWM Input Duty Cycle
//   <0=> 25%
//   <1=> 50%
//   <2=> 75%
//   <3=> 100%
#define RTE_LV8907UW_BLDC_ZPSEL  0

// </e>

// <e> 100% PWM Operation Mode
// <i> If 100% PWM input duty cycle was detected the motor can be turned off or
// <i> driven by predefined duty cycle.
// <i> Default: Off for BLDC-GEVK
#define RTE_LV8907UW_BLDC_PWMFL  0

// <o> 100% PWM Input Duty Cycle
//   <0=> 25%
//   <1=> 50%
//   <2=> 75%
//   <3=> 100%
#define RTE_LV8907UW_BLDC_FLSEL  0

// </e>

// MRCONF2

// <o> Dead Time Setting <0-31>
// <i> ranges from 0 (3.2 us) up to 31 (0.1 us).
// <i> Default: 7 (2.5 us) for BLDC-GEVK
#define RTE_LV8907UW_BLDC_FDTI  7

// <o> FG Signal Output Frequency
// <i> The FG signal is a representation of a successfully detected back-EMF
// <i> transition which occurs three times during every electrical revolution.
// <i> Default: One pulse every 2 electrical revolution for BLDC-GEVK
//   <0=> One transition per back-EMF detection
//   <1=> One pulse per electrical revolution
//   <2=> One transition every two BEMF det
//   <3=> One pulse every two elec. Revolutions
#define RTE_LV8907UW_BLDC_FGOF  3

// <e> Soft-start Function Enable
// <i> Soft-start (current ramp) allows slow startup of motors with higher inertia.
// <i> Default: Off for BLDC-GEVK
#define RTE_LV8907UW_BLDC_SSTEN  0

// <o> Soft-start Time Setting <0-63>
// <i> The soft start can be set from 0 (0.1 s) up to 63 (6.72 s).
// <i> Default: 0 for BLDC-GEVK
#define RTE_LV8907UW_BLDC_SSTT  0

// </e>

// MRCONF3

// PDTSEL in MRCONF1
// SSTT in MRCONF2

// MRCONF4

// <o> Startup commutation period <0-255>
// <i> Can range from 0 (0.82 ms) up to 255 (209.92 ms)
// <i> 0.82 * (1 + STOSC)
// <i> Default: 11 (9.84 ms) for BLDC-GEVK
#define RTE_LV8907UW_BLDC_STOSC  11

// MRCONF5

// <o> Current Limit Mask Time <0-15>
// <i> Can range from 0 (0.1 us) up to 15 (1.6 us)
// <i> 0.1 + (CLMASK / 10)
// <i> Default: 0 for BLDC-GEVK
#define RTE_LV8907UW_BLDC_CLMASK  0

// <o> Over-current Detection Mask Time <0-15>
// <i> Can range from 0 (0.2 us) up to 15 (3.2 us)
// <i> 0.2 * (1 + OCMASK)
// <i> Default: 0 for BLDC-GEVK
#define RTE_LV8907UW_BLDC_OCMASK  0

// MRCONF7

// <o> FET Short Protection Detection Voltage <0-15>
// <i> Vds voltage to detect FET Short status.
// <i> V_{th} = 0.1 + (FSCDL / 10) [V]
// <i> Default: 8 (0.9 V) for BLDC-GEVK
#define RTE_LV8907UW_BLDC_FSCDL  8

// <o> FET Short Protection Detection Time [us]
// <i> By monitoring FET Vds, the time from FET�s ON signal output until detecting Shorted status.
// <i> Default: 6.4 us for BLDC-GEVK
//   <0=> 3.2
//   <1=> 6.4
//   <2=> 9.6
//   <3=> 12.8
#define RTE_LV8907UW_BLDC_FSCDT  1

// <q> DIAG Output Selection at PWM Input Abnormality
// <i> Default: Disabled for BLDC-GEVK
#define RTE_LV8907UW_BLDC_PPDOSEL  0

// <q> Synchronous Rectification Enable
// <i> Defines synchronous rectification mode for the output stage.
// <i> Default: Disabled for BLDC-GEVK
#define RTE_LV8907UW_BLDC_SYNCEN  0

// MRCONF8

// <o> Junction Temperature Warning and Shutoff Levels
// <i> Default: 125�C, 150�C for BLDC-GEVK
//   <0=> 125�C, 150�C
//   <1=> 150�C, 175�C
#define RTE_LV8907UW_BLDC_TSTS  0

// <o> Threshold for External Thermometer Input [V]
// <i> V_{th} [V]
// <i> Default: 0.35 V for BLDC-GEVK
//   <0=> 0.35
//   <1=> 0.30
//   <2=> 0.25
//   <3=> 0.20
#define RTE_LV8907UW_BLDC_THTH  0

// <o> Open Loop Startup Timeout <0-15>
// <i> If no back-EMF is detected for the time programmed into CPTM register
// <i> the motor is turned off and a locked rotor is flagged.
// <i> Default: 0 (0.42 s / 3.36 s) for BLDC-GEVK
#define RTE_LV8907UW_BLDC_CPTM  0

// <q> Charge Pump Spread Spectrum
// <i> By activating SSCG it is possible to disperse frequency components of the charge pump switching frequency.
// <i> Default: Disabled for BLDC-GEVK
#define RTE_LV8907UW_BLDC_SSCG  0

// MRCONF9

// <e> Watchdog Enable
// <i> This bit can enable or disable the watchdog.
// <i> Default: Disabled for BLDC-GEVK
#define RTE_LV8907UW_BLDC_WDTEN  0

// <e> Operation Against Watchdog Timeout
// <i> Default: Turned off for BLDC-GEVK
#define RTE_LV8907UW_BLDC_WDTP  0

// <o> Operation mode selection after a Watchdog timeout
//   <0=> 25%
//   <1=> 50%
//   <2=> 75%
//   <3=> 100%
#define RTE_LV8907UW_BLDC_WDTSEL  0

// </e>

// <o> Watchdog Timer <0-63>
// <i> Can range from 0 (1.64 ms) up to 63 (104.96 ms)
// <i> 1.64 * (1 + WDT) [ms]
#define RTE_LV8907UW_BLDC_WDT  0

// </e>

// MRCONF10

// <o> Diagnosis Output Polarity Selection
// <i> This bit selects the polarity of the DIAG signal (open-drain).
// <i> Default: Active low for BLDC-GEVK
//   <0=> Active low
//   <1=> Active high
#define RTE_LV8907UW_BLDC_DIAGSEL  0

// <h> Error and Warning Masks
// <i> These masks define whether DIAG pin transition occurs when the respective warning / error occurs.

// <q> Over-current protection disable
// <i>
// <i> Default:  for BLDC-GEVK
#define RTE_LV8907UW_BLDC_OCPEN  0

// <q> Over-voltage protection disable
// <i>
// <i> Default:  for BLDC-GEVK
#define RTE_LV8907UW_BLDC_OVPEN  0

// <q> FET short protection disable
// <i>
// <i> Default:  for BLDC-GEVK
#define RTE_LV8907UW_BLDC_FSPEN  0

// <q> Thermal protection disable
// <i>
// <i> Default:  for BLDC-GEVK
#define RTE_LV8907UW_BLDC_THPEN  0

// <q> Thermal warning output disable
// <i>
// <i> Default:  for BLDC-GEVK
#define RTE_LV8907UW_BLDC_THWEN  0

// <q> Motor block protection disable
// <i>
// <i> Default:  for BLDC-GEVK
#define RTE_LV8907UW_BLDC_CPEN  0

// <q> VCC Under-voltage protection disable
// <i>
// <i> Default:  for BLDC-GEVK
#define RTE_LV8907UW_BLDC_VCLVPEN  0

// </h>

// MRCONF11

// <o> Diagnostic Output Mode Selection
// <i> Selects which errors/warnings will actually trigger a DIAG transition.
// <i> Default: Any non-masked error for BLDC-GEVK
//   <0=> Any non-masked error
//   <1=> Only for latched errors
#define RTE_LV8907UW_BLDC_DLTO  0

// <h> Latched errors enable
// <i> The faults of the motor block, FET Short and over-current can cause intolerable large-current.
// <i> To prevent repeated current flow during re-try attempts, it is possible to latch these errors.
// <i> The LV8907 will remain disabled until the latch is cleared by the register MRRST.

// <q> Latch the IC off after over-current
// <i> Default: Enabled for BLDC-GEVK
#define RTE_LV8907UW_BLDC_OCPLT  1

// <q> Latch the IC off after a FET short
// <i> Default: Enabled for BLDC-GEVK
#define RTE_LV8907UW_BLDC_FSPLT  1

// <q> Latch the IC off after a motor block
// <i> Default: Disabled for BLDC-GEVK
#define RTE_LV8907UW_BLDC_CPLT  0

// </h>

// WDTSEL in MRCONF9

// <o> Mode Setting at the Time of Speed Feedback Deceleration
// <i> DWNSET allows for various degrees of energy recuperation.
// <i> Default: Sync OFF Mode for BLDC-GEVK
//   <0=> Normal Mode
//   <1=> Sync OFF Mode
//   <2=> Slow Response Mode
#define RTE_LV8907UW_BLDC_DWNSET  0

// MRCONF12

// <o> Lead Angle Setting <0-15>
// <i> Can range from 0 (0�) up to 15 (28.125�).
// <i> LASET * 1.875
// <i> Default: 0 for BDK-GEVK
#define RTE_LV8907UW_BLDC_LASET  0

// <o> Sinusoidal vs. Trapezoidal Drive Mode Selection
// <i> This bit selects whether the motor phases are driven with a trapezoidal or pseudo-sinusoidal signal.
// <i> Default: Trapezoidal Drive for BDK-GEVK
//   <0=> Trapezoidal drive
//   <1=> Sinusoidal drive
#define RTE_LV8907UW_BLDC_SLMD  0

// <o> Ramp Imposed on Speed Control Changes
// <i> The LV8907 allows to impose a limit on the difference between target speed and actual speed such that
// <i> every electrical revolution only a fraction of the previous rotational (PROT) speed is allowed to change.
// <i> Default: PROT for BDK-GEVK
//   <0=> PROT
//   <1=> PROT/2
//   <2=> PROT/4
//   <3=> PROT/8
//   <4=> PROT/16
//   <5=> PROT/32
#define RTE_LV8907UW_BLDC_STEPSEL  0

// <h> Proportional Gain
// <i> Proportional Gain can be set with PX and PG of MRSPCT0.
// <i> The total gain is the product of both components PG and PX.

// <o> PG
// <i> Proportional Gain can be set with PX and PG of MRSPCT0.
// <i> The total gain is the product of both components PG and PX.
// <i> Default:  for BDK-GEVK
//   <0=> 1
//   <1=> 2
//   <2=> 4
//   <3=> 8
//   <4=> 16
//   <5=> 32
//   <6=> 64
//   <7=> 0
#define RTE_LV8907UW_BLDC_PG  3

// <o> PX
// <i> Proportional Gain can be set with PX and PG of MRSPCT0.
// <i> The total gain is the product of both components PG and PX.
// <i> Default:  for BDK-GEVK
//   <0=> 1
//   <1=> 7/8
//   <2=> 6/8
//   <3=> 5/8
//   <4=> 4/8
//   <5=> 3/8
//   <6=> 2/8
//   <7=> 1/8
#define RTE_LV8907UW_BLDC_PX  0

// </h>

// <h> Integrator Gain
// <i> Integral Gain can be set with IX, and IG of MRSPCT1 respectively.
// <i> The total gain is the product of both components IG and IX.

// <o> IG
// <i> Integral Gain can be set with IX, and IG of MRSPCT1 respectively.
// <i> The total gain is the product of both components IG and IX.
// <i> Default:  for BDK-GEVK
//   <0=> 1
//   <1=> 2
//   <2=> 4
//   <3=> 8
//   <4=> 16
//   <5=> 32
//   <6=> 64
//   <7=> 0
#define RTE_LV8907UW_BLDC_IG  0

// <o> IX
// <i> Integral Gain can be set with IX, and IG of MRSPCT1 respectively.
// <i> The total gain is the product of both components IG and IX.
// <i> Default:  for BDK-GEVK
//   <0=> 1
//   <1=> 7/8
//   <2=> 6/8
//   <3=> 5/8
//   <4=> 4/8
//   <5=> 3/8
//   <6=> 2/8
//   <7=> 1/8
#define RTE_LV8907UW_BLDC_IX  0

// </h>

// </h>

// <h> Motor configuration

// <o> Motor Pole Pair Count <1-64>
// <i> This value is needed to convert Electrical RPM to Physical RPM.
// <i> Default: 6 for motor provided with BLDC-GEVK
#define RTE_LV8907UW_BLDC_MOTOR_POLE_PAIRS  6

// </h>

// <e> ERPM Measuring
// <i> Allows to measure real motor RPM by counting the FG pin pulses sent to BDK.
// <i> ERPM measurement is supported only when FG signal output frequency is set to 1 or 2 pulses per electrical revolution.
// <i> Default: Enabed for BLDC-GEVK
#define RTE_LV8907UW_BLDC_ERPM_MEASUREMENT  1

// <o> FG signal DIO Pad <0-15>
// <i> Select the physical DIO pad where the FG signal is connected.
// <i> Default: 11 for combination of BDK-GEVK and BLDC-GEVK
#define RTE_LV8907UW_BLDC_FG_PAD  11

// <o> DIO Interrupt Source <0-3>
// <i> Which of the four DIO interrupt sources to use for FG pin transitions.
// <i> Default: 3 for BDK-GEVK
#define RTE_LV8907UW_BLDC_FG_INT_SRC  3

// </e>

// <<< end of configuration section >>>

#endif /* RTE_BDK_LV8907UW_BLDC_H_ */

//! \}
//! \}
//! \}
//! \}
