//-----------------------------------------------------------------------------
// Copyright (c) 2018 Semiconductor Components Industries LLC
// (d/b/a "ON Semiconductor").  All rights reserved.
// This software and/or documentation is licensed by ON Semiconductor under
// limited terms and conditions.  The terms and conditions pertaining to the
// software and/or documentation are available at
// http://www.onsemi.com/site/pdf/ONSEMI_T&C.pdf ("ON Semiconductor Standard
// Terms and Conditions of Sale, Section 8 Software") and if applicable the
// software license agreement.  Do not use this software and/or documentation
// unless you have carefully read and you agree to the limited terms and
// conditions.  By using this software and/or documentation, you agree to the
// limited terms and conditions.
//-----------------------------------------------------------------------------
//! \file RTE_BDK_PCA9655E.h
//!
//! This file contains the Run Time Configuration (RTE) options for PCA9655E
//! CMSIS Component.
//!
//! These options can be edited by opening this file in CMSIS Configuration
//! Wizard Editor that is part of Eclipse installation.
//!
//! \addtogroup BDK_GRP
//! \{
//! \addtogroup API
//! \{
//! \addtogroup PCA9655E_GRP PCA9655E IO Expander
//! \{
//! \name BDK-GEVK RTE Configuration
//! \{
//! These parameters are part of the \ref RTE_PCA9655E.h RTE configuration
//! file and can be used to adjust library behavior.
//! This file is copied into the Eclipse project when the PCA9655E component
//! is selected and can be edited by using the <i>CMIS Configuration Wizard</i>
//! editor.
//!
//! \image html rte_pca9655e.jpg
//!
//-----------------------------------------------------------------------------

#ifndef RTE_BDK_PCA9655E_H_
#define RTE_BDK_PCA9655E_H_

// <<< Use Configuration Wizard in Context Menu >>>

// <e> Enable PCA9655E shared interrupts
// <i> This is required for proper functionality of most IDK shields.
#ifndef RTE_PCA9655E_INT_ENABLED
#define RTE_PCA9655E_INT_ENABLED          1
#endif

// <o> Interrupt signal DIO Pad <0-15>
// <i> DIO used for IO expanders interrupt signal.
// <i> Default: DIO13 for BDK-GEVK board.
#ifndef RTE_PCA9655E_DIO_INT_PIN
#define RTE_PCA9655E_DIO_INT_PIN          13
#endif

// <o> DIO Interrupt Source <0-3>
// <i> Which of the four DIO interrupt sources to use.
// <i> Default: 0
#ifndef RTE_PCA9655E_DIO_INT_SRC
#define RTE_PCA9655E_DIO_INT_SRC          0
#endif

// <o> EventCallback event ID <0-65535>
// <i> This number is used to assign multiple callbacks to PCA9655E interrupt event.
// <i> It is used by other shield components that rely on shared interrupt line.
#ifndef RTE_PCA9655E_EVENT_CALLBACK_ID
#define RTE_PCA9655E_EVENT_CALLBACK_ID    1234
#endif

// </e>

// <<< end of configuration section >>>

#endif /* RTE_BDK_PCA9655E_H_ */

//! \}
//! \}
//! \}
//! \}
