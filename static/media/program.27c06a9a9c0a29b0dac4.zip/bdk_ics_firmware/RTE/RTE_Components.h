/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: bdk_ics_firmware
 * RTE configuration: bdk_ics_firmware.rteconfig
*/
#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

/*
 * Define the Device Header File:
*/
#define CMSIS_device_header "rsl10.h"

/* ONSemiconductor.BDK-GEVK::Board Support.ICS Protocol.ALS Node */
#define RTE_ICS_PROTOCOL_NODE_ALS BDK_ALS_GEVB
/* ONSemiconductor.BDK-GEVK::Board Support.ICS Protocol.AO Node */
#define RTE_ICS_PROTOCOL_NODE_AO BDK_MULTI_SENSE_GEVB
/* ONSemiconductor.BDK-GEVK::Board Support.ICS Protocol.BLDC Node */
#define RTE_ICS_PROTOCOL_NODE_BLDC BDK_BLDC_GEVK
/* ONSemiconductor.BDK-GEVK::Board Support.ICS Protocol.ENV Node.BSEC */
#define RTE_ICS_PROTOCOL_NODE_ENV BDK_MULTI_SENSE_GEVB
/* ONSemiconductor.BDK-GEVK::Board Support.ICS Protocol.LEDB Node */
#define RTE_ICS_PROTOCOL_NODE_LEDB BDK_D_LED_B_GEVK
/* ONSemiconductor.BDK-GEVK::Board Support.ICS Protocol.PIR Node */
#define RTE_ICS_PROTOCOL_NODE_PIR BDK_PIR_GEVB
/* ONSemiconductor.BDK-GEVK::Board Support.ICS Protocol.STPR Node */
#define RTE_ICS_PROTOCOL_NODE_STPR BDK_D_STPR_GEVK
/* ONSemiconductor.BDK-GEVK::Board Support.ICS Protocol.System Node */
#define RTE_ICS_PROTOCOL_NODE_SYS BDK_GEVK
/* ONSemiconductor.BDK-GEVK::Board Support.IDK Shields.AMIS30543_STPR.D-STPR-GEVK */
#define RTE_BDK_BOARD_SUPPORT_IDK_AMIS30543_STPR
/* ONSemiconductor.BDK-GEVK::Board Support.IDK Shields.BME680_BSEC.MULTI-SENSE-GEVB */
#define RTE_BDK_BOARD_SUPPORT_IDK_BME680_BSEC
/* ONSemiconductor.BDK-GEVK::Board Support.IDK Shields.BNO055_NDOF.MULTI-SENSE-GEVB */
#define RTE_BDK_BOARD_SUPPORT_IDK_BNO055_NDOF
/* ONSemiconductor.BDK-GEVK::Board Support.IDK Shields.LV8907UW_BLDC.BLDC-GEVK */
#define RTE_BDK_BOARD_SUPPORT_IDK_LV8907UW_BLDC
/* ONSemiconductor.BDK-GEVK::Board Support.IDK Shields.NCS36000_PIR.PIR-GEVB */
#define RTE_BDK_BOARD_SUPPORT_IDK_NCS36000_PIR
/* ONSemiconductor.BDK-GEVK::Board Support.IDK Shields.NCV78763_LED.D-LED-B-GEVK */
#define RTE_BDK_BOARD_SUPPORT_IDK_NCV78763_LED
/* ONSemiconductor.BDK-GEVK::Board Support.IDK Shields.NOA1305_ALS.ALS-GEVB */
#define RTE_BDK_BOARD_SUPPORT_IDK_NOA1305_ALS
/* ONSemiconductor.BDK-GEVK::Board Support.Libraries.Button */
#define RTE_BDK_BOARD_SUPPORT_LIBRARIES_BUTTON
/* ONSemiconductor.BDK-GEVK::Board Support.Libraries.LED */
#define RTE_BDK_BOARD_SUPPORT_LIBRARIES_LED
/* ONSemiconductor.BDK-GEVK::Board Support.Libraries.PCA9655E */
#define RTE_BDK_BOARD_SUPPORT_LIBRARIES_PCA9655E
/* ONSemiconductor.BDK-GEVK::Board Support.Pinmap */
#define RTE_BDK_BOARD_SUPPORT BDK_GEVK
/* ONSemiconductor.BDK::BLE.Peripheral Server.BASS */
#define RTE_BDK_BLE_PERIPHERAL_SERVER_BASS
/* ONSemiconductor.BDK::BLE.Peripheral Server.ICS */
#define RTE_BDK_BLE_PERIPHERAL_SERVER_ICS
/* ONSemiconductor.BDK::BLE.Peripheral Server.Peripheral Server */
#define RTE_BDK_BLE_PERIPHERAL_SERVER
/* ONSemiconductor::Components.Ambient Light Sensor.NOA1305 */
#define RTE_COMPONENTS_NOA1305
/* ONSemiconductor::Components.Environmental Sensor.BME680 */
#define RTE_COMPONENTS_BME680
/* ONSemiconductor::Components.Environmental Sensor.BSEC.Normal */
#define RTE_COMPONENTS_BSEC NORMAL_VERSION
/* ONSemiconductor::Components.LED Driver.NCV78763 */
#define RTE_COMPONENTS_NCV78763
/* ONSemiconductor::Components.Motion Sensor.BNO055 */
#define RTE_COMPONENTS_BNO055
/* ONSemiconductor::Components.Motor Driver.AMIS30543 */
#define RTE_COMPONENTS_AMIS30543
/* ONSemiconductor::Components.Motor Driver.LV8907UW */
#define RTE_COMPONENTS_LV8907UW
/* ONSemiconductor::Device.BDK.AES */
#define RTE_DEVICE_BDK_AES
/* ONSemiconductor::Device.BDK.Event Callback */
#define RTE_DEVICE_BDK_EVENT_CALLBACK
/* ONSemiconductor::Device.BDK.HAL */
#define RTE_DEVICE_BDK_HAL
/* ONSemiconductor::Device.BDK.Output Redirection.SEGGER RTT */
#define RTE_DEVICE_BDK_OUTPUT_REDIRECTION SEGGER_RTT
/* ONSemiconductor::Device.BDK.Scheduling */
#define RTE_DEVICE_BDK_SCHEDULING
/* ONSemiconductor::Device.BDK.Software Timer */
#define RTE_DEVICE_BDK_SOFTWARE_TIMER

#endif /* RTE_COMPONENTS_H */
