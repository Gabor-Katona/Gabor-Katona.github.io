//-----------------------------------------------------------------------------
// Copyright (c) 2018 Semiconductor Components Industries LLC
// (d/b/a "ON Semiconductor").  All rights reserved.
// This software and/or documentation is licensed by ON Semiconductor under
// limited terms and conditions.  The terms and conditions pertaining to the
// software and/or documentation are available at
// http://www.onsemi.com/site/pdf/ONSEMI_T&C.pdf ("ON Semiconductor Standard
// Terms and Conditions of Sale, Section 8 Software") and if applicable the
// software license agreement.  Do not use this software and/or documentation
// unless you have carefully read and you agree to the limited terms and
// conditions.  By using this software and/or documentation, you agree to the
// limited terms and conditions.
//-----------------------------------------------------------------------------
#include <stdio.h>

#include <BDK.h>
#include <BSP_Components.h>
#include <BLE_Components.h>

#include <ics/CS.h>
#include <ics/CS_Nodes.h>

static void APP_AddCSNodes(void);

int main(void)
{
    /* Initialize all needed BDK components. */
    BDK_Initialize();

    /* Initialize CS protocol, start Peripheral Server, Add Custom Service
     * Profile to it.
     */
    CS_Init();

    /* Optionally set advertising interval to be 200 to 250 ms long. */
    BDK_BLE_SetAdvertisementInterval(320, 400);

    /* Optionally set custom device name.
     * The name needs to contain one of 'IDK', 'BDK', 'RSL10' patterns to be
     * recognized by RSL10 Sense & control mobile application.
     * Default: 'BDK_BLE_Terminal'
     */
     BDK_BLE_SetLocalName("BDK_BLE_Terminal");

    /* Also add battery service if its component is enabled. */
#if defined (RTE_BDK_BLE_PERIPHERAL_SERVER_BASS)
    BLE_BASS_Initialize(1000, 16);
    BLE_BASS_SetVoltageRange(CALC_VBAT_MEASURED(2.5f), CALC_VBAT_MEASURED(3.0f));
    // BLE_BASS_SetBattLevelInd(BattLevelChangeCallback);
#endif /* RTE_BDK_BLE_BASS_PRESENT */

    /* Add all enabled Custom Service Nodes. */
    APP_AddCSNodes();

    CS_SYS_Info("Entering main loop.");
    while (1)
    {
        /* Execute any events that have occurred and refresh Watchdog. */
        BDK_Schedule();

        /* Enter sleep mode until an interrupt occurs. */
        SYS_WAIT_FOR_INTERRUPT;
    }

    return 0;
}

/** Registers those sensor / actuator nodes whose components are enabled. */
static void APP_AddCSNodes(void)
{
#ifdef RTE_ICS_PROTOCOL_NODE_ALS
    if (CSN_ALS_CheckAvailability() == true)
    {
        CS_RegisterNode(CSN_ALS_Create());
    }
#endif /* RTE_BDK_ICS_NODE_ALS */

#ifdef RTE_ICS_PROTOCOL_NODE_PIR
    if (CSN_PIR_CheckAvailibility() == true)
    {
        CS_RegisterNode(CSN_PIR_Create());
    }
#endif /* RTE_BDK_ICS_NODE_PIR */

#ifdef RTE_ICS_PROTOCOL_NODE_ENV
    if (CSN_ENV_CheckAvailability() == true)
    {
        CS_RegisterNode(CSN_ENV_Create());
    }
#endif /* RTE_BDK_ICS_NODE_ENV */

#ifdef RTE_ICS_PROTOCOL_NODE_AO
    if (CSN_AO_CheckAvailability() == true)
    {
        CS_RegisterNode(CSN_AO_Create());
    }
#endif /* RTE_BDK_ICS_NODE_ENV */

#ifdef RTE_ICS_PROTOCOL_NODE_STPR
    if (CSN_STPR_CheckAvailability() == true)
    {
        CS_RegisterNode(CSN_STPR1_Create());
        CS_RegisterNode(CSN_STPR2_Create());
    }
#endif /* RTE_BDK_ICS_NODE_STPR */

#ifdef RTE_ICS_PROTOCOL_NODE_LEDB
    if (CSN_LEDB_CheckAvailability() == true)
    {
        CS_RegisterNode(CSN_LEDB_Create());
    }
#endif /* RTE_BDK_ICS_NODE_STPR */

#ifdef RTE_ICS_PROTOCOL_NODE_BLDC
    if (CSN_BLDC_CheckAvailability() == true)
    {
    	CS_RegisterNode(CSN_BLDC_Create());
    }
#endif /* RTE_ICS_PROTOCOL_NODE_BLDC */
}

